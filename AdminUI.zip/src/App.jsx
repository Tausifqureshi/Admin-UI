import React from "react";
import Admin from "./components/Admin";
const App = () => {
  return (
    <>  
      <Admin />
    </>
  );
}; 

export default App;
